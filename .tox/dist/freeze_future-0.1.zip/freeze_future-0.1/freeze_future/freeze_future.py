'''
When using the future library

disutils is getting fucked up

trys to fix ok lets go
'''
import sys

import future

if sys.version_info[0] > 2:
	PY3 = True
else:
	PY3 = False

#TBD find how disutils finds the packages, emulate and do a re expresiion
EXCLUDES_LIST = ('urllib.StringIO',          
				'urllib.UserDict',          
				'urllib.__builtin__',       
				'urllib.__future__',        
				'urllib.__main__',          
				'urllib._abcoll',           
				'urllib._collections',      
				'urllib._functools',        
				'urllib._hashlib',          
				'urllib._heapq',            
				'urllib._io',               
				'urllib._locale',           
				'urllib._md5',              
				'urllib._random',           
				'urllib._sha',              
				'urllib._sha256',           
				'urllib._sha512',           
				'urllib._socket',           
				'urllib._sre',              
				'urllib._ssl',              
				'urllib._struct',           
				'urllib._subprocess',       
				'urllib._threading_local',  
				'urllib._warnings',         
				'urllib._weakref',          
				'urllib._weakrefset',       
				'urllib._winreg',           
				'urllib.abc',               
				'urllib.array',             
				'urllib.base64',            
				'urllib.bdb',               
				'urllib.binascii',          
				'urllib.cPickle',           
				'urllib.cStringIO',         
				'urllib.calendar',          
				'urllib.cmd',               
				'urllib.collections',       
				'urllib.contextlib',        
				'urllib.copy',              
				'urllib.copy_reg',          
				'urllib.datetime',          
				'urllib.difflib',           
				'urllib.dis',               
				'urllib.doctest',           
				'urllib.dummy_thread',      
				'urllib.email',             
				'urllib.email.utils',       
				'urllib.encodings',         
				'urllib.encodings.aliases', 
				'urllib.errno',             
				'urllib.exceptions',        
				'urllib.fnmatch',           
				'urllib.ftplib',            
				'urllib.functools',         
				'urllib.gc',                
				'urllib.genericpath',       
				'urllib.getopt',            
				'urllib.getpass',           
				'urllib.gettext',           
				'urllib.hashlib',           
				'urllib.heapq',
				'urllib.httplib',
				'urllib.imp',
				'urllib.inspect',           
				'urllib.io',                
				'urllib.itertools',         
				'urllib.keyword',           
				'urllib.linecache',         
				'urllib.locale',            
				'urllib.logging',           
				'urllib.marshal',           
				'urllib.math',              
				'urllib.mimetools',         
				'urllib.mimetypes',         
				'urllib.msvcrt',            
				'urllib.nt',                
				'urllib.ntpath',            
				'urllib.nturl2path',        
				'urllib.opcode',            
				'urllib.operator',          
				'urllib.optparse',          
				'urllib.os',                
				'urllib.os2emxpath',        
				'urllib.pdb',           
				'urllib.pickle',            
				'urllib.posixpath',         
				'urllib.pprint',            
				'urllib.quopri',            
				'urllib.random ',           
				'urllib.re',                
				'urllib.repr',              
				'urllib.rfc822',            
				'urllib.robotparser',       
				'urllib.select',            
				'urllib.shlex',             
				'urllib.signal',            
				'urllib.socket',            
				'urllib.sre_compile',       
				'urllib.sre_constants',     
				'urllib.sre_parse',         
				'urllib.ssl',               
				'urllib.stat',              
				'urllib.string',            
				'urllib.strop',             
				'urllib.struct',            
				'urllib.subprocess',        
				'urllib.sys',               
				'urllib.tempfile',          
				'urllib.textwrap',          
				'urllib.thread',            
				'urllib.threading',         
				'urllib.time',              
				'urllib.token',             
				'urllib.tokenize',          
				'urllib.traceback',         
				'urllib.types',             
				'urllib.unittest',          
				'urllib.unittest.case',     
				'urllib.unittest.loader',   
				'urllib.unittest.main',     
				'urllib.unittest.result',   
				'urllib.unittest.runner',   
				'urllib.unittest.signals',  
				'urllib.unittest.suite',    
				'urllib.unittest.util',     
				'urllib.urllib',            
				'urllib.urlparse',          
				'urllib.uu',                
				'urllib.warnings',          
				'urllib.weakref',
				'collections.sys',
				'collections.abc'
				'collections.types'
				'collections._weakrefset',
				'collections._weakref',)


INCLUDES_LIST = (
				#~ 'UserList',
				#~ 'UserString',
				#~ 'commands',
				'future',)

#~ INCLUDES_LIST = []
def parse(excludes, includes):
	'''
	Excludes urllib subpaths on python2
	'''
	# is the user running the future package
	if not sys.modules.get('future'):
		return False
	
	if not excludes:
		excludes = []
	
	if not includes:
		includes = []
	
	excludes.extend(EXCLUDES_LIST)
	includes.extend(INCLUDES_LIST)
	return excludes, includes

def using_future(executables):
	for aexec in executables:
		with open(aexec.script, 'r') as file:
			for i, line in enumerate(file):
				if 'install_aliases()' in line:
					return True

	else:
		return False
			
def setup(dist_setup, **options):
	if using_future(options['executables']):
		excludes, includes = parse(list(options['options']['build_exe']['excludes']),
								list(options['options']['build_exe']['packages']))
		options['options']['build_exe']['excludes'] = excludes
		options['options']['build_exe']['packages'] = includes
		
		dist_setup(**options)
		return True
	else:
		dist_setup(**options)
		return False
